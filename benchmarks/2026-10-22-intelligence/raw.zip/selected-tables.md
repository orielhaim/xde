## Selected matched results

Aggregate useful MiB/s; all three observations are shown in trial order. Ratios are paired current/baseline throughput, not ratios of independent medians.

| Workload | Previous adaptive | Selected adaptive | Fixed reference | Paired ratios |
| --- | --- | --- | --- | --- |
| h1-cold | 13.208, 13.228, 13.205 | 25.634, 26.632, 26.245 | 31.825, 31.829, 31.826 | 1.941, 2.013, 1.987 |
| h1-heterogeneous | 15.783, 15.742, 15.630 | 15.386, 15.440, 15.587 | 15.969, 15.969, 15.970 | 0.975, 0.981, 0.997 |
| h1-long | 20.833, 20.707, 20.782 | 30.132, 29.775, 30.005 | 31.952, 31.953, 31.957 | 1.446, 1.438, 1.444 |
| h1-small | 61.093, 61.307, 63.614 | 30.961, 58.975, 61.228 | 64.348, 56.809, 67.079 | 0.507, 0.962, 0.962 |
| h2-heterogeneous | 14.355, 14.462, 14.897 | 14.537, 14.419, 14.331 | 14.328, 14.371, 14.431 | 1.013, 0.997, 0.962 |
| h2-loopback | 880.415, 858.232, 969.247 | 841.360, 841.605, 840.249 | 759.848, 839.864, 888.882 | 0.956, 0.981, 0.867 |
| h2-shared | 31.380, 31.333, 31.336 | 30.983, 30.868, 31.124 | 31.875, 31.892, 31.830 | 0.987, 0.985, 0.993 |
| h3-heterogeneous | 14.696, 14.946, 14.825 | 14.314, 14.491, 14.700 | 15.005, 15.068, 14.673 | 0.974, 0.970, 0.992 |
| h3-loopback | 211.881, 218.561, 215.964 | 214.814, 208.384, 213.372 | 216.347, 214.018, 218.483 | 1.014, 0.953, 0.988 |
| h3-shared | 15.854, 15.836, 15.349 | 15.046, 15.040, 15.117 | 15.710, 15.920, 15.932 | 0.949, 0.950, 0.985 |

Full p10/median/p90/min/max, individual completion times, payload intervals, CPU attribution and request records are in `selected/analysis.json` and raw JSON. Three observations are not enough to distinguish small changes confidently.

## Observed control cost

| Workload | Controller handling % (all selected trials) | Planner evaluations | Topology changes |
| --- | --- | --- | --- |
| h1-cold | 0.021, 0.022, 0.019 | 19, 18, 18 | 3, 1, 1 |
| h1-heterogeneous | 0.025, 0.019, 0.019 | 96, 104, 95 | 8, 6, 8 |
| h1-long | 0.020, 0.020, 0.022 | 63, 67, 66 | 3, 5, 5 |
| h1-small | 0.526, 0.779, 0.709 | 0, 0, 0 | 0, 0, 0 |
| h2-heterogeneous | 0.014, 0.014, 0.014 | 45, 45, 45 | 4, 4, 4 |
| h2-loopback | 0.022, 0.022, 0.023 | 18, 17, 18 | 0, 0, 0 |
| h2-shared | 0.029, 0.025, 0.026 | 62, 64, 62 | 8, 8, 8 |
| h3-heterogeneous | 0.015, 0.014, 0.013 | 43, 42, 42 | 4, 4, 4 |
| h3-loopback | 0.013, 0.013, 0.013 | 73, 75, 73 | 10, 8, 10 |
| h3-shared | 0.019, 0.024, 0.016 | 62, 62, 64 | 9, 10, 8 |

Planner state: 384 bytes/job; assignment control: 24 bytes/assignment. These are structure sizes, not total job/transport RSS.
